const Auth = require("../model/Auth");
const nodemailer = require("nodemailer");
async function resetpassword(req, res) {
  const { email } = req.body;
  let user = await Auth.findOne({ email });

  if (!user) {
    return res.json({ err: 1, msg: "This email has not been registered!" });
  }
  try {
    let mailTransporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "galineelam10@gmail.com",
        pass: "swfhmwfdmqnzvkqx",
      },
    });

    let mailDetails = {
      from: "galineelam10@gmail.com",
      to: email,
      subject: "Reset Password Link",
      html: " <p> <a href='http://localhost:3000/changepasswordscreen'>Click Here </a> </p>",
    };

    mailTransporter.sendMail(mailDetails, function (err, data) {
      if (err) {
        res.json("Error Occurs");
      } else {
        res.json("Email sent successfully");
      }
    });
  } catch (ex) {
    res.status(400).json(ex.message);
  }
}
module.exports = { resetpassword };
